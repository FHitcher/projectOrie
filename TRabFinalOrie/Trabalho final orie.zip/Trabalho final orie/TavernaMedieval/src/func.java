public interface func {
    public boolean ehMaior();
}
